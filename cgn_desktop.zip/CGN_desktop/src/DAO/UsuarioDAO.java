package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import Classes.Usuario;
import Classes.Conexao;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UsuarioDAO {

    public boolean buscarUsuario(Usuario usuario) throws SQLException {

         try {
            Conexao conexao = new Conexao();
            Connection con = conexao.conector();
            Statement stm;
            ResultSet rs;

            stm = con.createStatement();
            rs = stm.executeQuery("SELECT * FROM usuario where nome =  '" + usuario.getNome() + "' and senha = '" + usuario.getSenha() + "'");

            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (ClassNotFoundException ex) {
            
        }
       return false; 
    }


}
